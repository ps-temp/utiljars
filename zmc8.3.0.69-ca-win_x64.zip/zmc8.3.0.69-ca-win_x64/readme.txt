 Certain portions  of this software are based on source code from OpenJDK
(http://openjdk.java.net/)  and  licensed  under  the GNU General  Public
License  version  2  (GPLv2)  with   the  Classpath  Exception   (http://
openjdk.java.net/legal/gplv2+ce.html).  Certain portions of this software 
are licensed  under  open source license agreements  that require  making
the source code available to a licensee. For a period of three years from
the date of your receipt of this software, Azul will provide upon request,
a complete  machine readable  copy of the  source code  for such portions
based on  OpenJDK on a medium  customarily used  for software interchange
for  a charge  no more  than  the cost  of physically  performing  source 
distribution.

  Please email azul_openjdk@azul.com for further information.

  Include this version code in your email:
  ZMC 8.3.0.69-ca  19009de5870d42b949b16f486d5420e0ef14809e
